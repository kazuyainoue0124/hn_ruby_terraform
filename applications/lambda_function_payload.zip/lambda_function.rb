def lambda_handler(event:, context:)
  "Hello Lambda!"
end
